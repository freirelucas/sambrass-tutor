# O Caminho do Sambrass — Trompete

Curso pessoal progressivo (6 semanas, 1h30/dia) para dominar o repertório do
caderno de naipe **Sambrass23** no trompete Bb. Nível-alvo: intermediário.
Meta dupla: (1) tocar a melodia inteira de cada peça e (3) ler à primeira vista com fluência.

## Estrutura
```
sambrass_course/
├── data/
│   ├── musicas.json     # banco de metadados (30 catalogadas; schema p/ 110)
│   ├── musicas.csv      # espelho tabular para análise rápida
│   └── jornada.json     # currículo das 6 semanas + rotina diária + vocabulário
├── scores/              # 110 partituras recortadas (sb-001.png … sb-110.png)
├── site/                # GitHub Page gerada (index.html + scores/)
└── scripts/
    ├── recortar.py      # recorta as 110 do PDF, sem a faixa de letras
    ├── gerar_banco.py   # constrói musicas.json
    └── build_site.py    # gera site/index.html a partir dos data/*.json
```

## Como funciona o banco
Cada música tem: tom, compasso, densidade, forma (seções), `celulas` rítmicas
recorrentes, `arpejos`, `requisitos` técnicos e `dificuldade` (1–10).
O catálogo de células (C1–C7) e arpejos (A1–A4) está em `data/musicas.json > _meta`.

- **15 músicas `verificada: true`** — lidas visualmente direto da partitura (dados confiáveis).
- **15 `verificada: false`** — estrutura pronta; tom/dificuldade/requisitos a confirmar.

## Próximos passos (no Claude Code)
1. Completar a verificação das 15 pendentes (abrir `scores/sb-NNN.png`, preencher campos).
2. Escalar o banco de 30 → 110 (mesmo schema).
3. Gerar os **snippets** que isolam cada célula (C1–C7) em VexFlow — pasta `snippets/` sugerida.
4. `python3 scripts/build_site.py` rerenderiza o site após qualquer mudança nos dados.
5. Publicar `site/` no GitHub Pages.

## Direitos autorais
As **letras** das canções NÃO são reproduzidas (obras protegidas). As partituras
foram recortadas para remover o bloco de letras; rótulos de seção que sobram na
pauta são incidentais. Material de estudo pessoal.

## Restrições técnicas de HTML (deploy)
Arquivo único, sem build; fontes de sistema; 17px base; tap targets ≥36px;
compatível com dispositivos Samsung antigos.
