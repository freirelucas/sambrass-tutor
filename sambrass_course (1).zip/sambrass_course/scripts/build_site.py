#!/usr/bin/env python3
"""Gera o site estático 'O Caminho do Sambrass' a partir dos JSON em data/.
Saída: site/index.html (single-file, sem dependências, pronto p/ GitHub Pages).
Rodar:  python3 scripts/build_site.py
"""
import json, html, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
data = json.load(open(ROOT/"data"/"musicas.json", encoding="utf-8"))
jornada = json.load(open(ROOT/"data"/"jornada.json", encoding="utf-8"))
musicas = {m["num"]: m for m in data["musicas"]}
cel = data["_meta"]["celulas_catalogo"]
arp = data["_meta"]["arpejos_catalogo"]

def esc(s): return html.escape(str(s))

def card_musica(m):
    dif = m["dificuldade"]
    badge = f'<span class="dif d{dif}">dif {dif}</span>' if dif else '<span class="dif dna">a verificar</span>'
    reqs = "".join(f'<span class="req">{esc(r)}</span>' for r in m["requisitos"])
    cels = " ".join(m["celulas"])
    return f'''<article class="musica" id="m{m['num']:03d}">
      <div class="mhead"><span class="mnum">{m['num']:03d}</span>
        <div><h4>{esc(m['titulo'])}</h4><div class="comp">{esc(m['compositor'])}</div></div>
        {badge}</div>
      <div class="mmeta">{esc(m['tom'])} · {esc(m['compasso'])} · {esc(m['densidade'])} · forma {('/'.join(m['forma']) or '?')}</div>
      <div class="reqs">{reqs}</div>
      <div class="cels">{esc(cels)}</div>
      <img loading="lazy" src="{esc(m['score_img'])}" alt="Partitura {esc(m['titulo'])}">
      <p class="obs">{esc(m['obs'])}</p>
    </article>'''

def secao_semana(s):
    foco = "".join(
        f'<li><a href="#m{n:03d}">{n:03d} — {esc(musicas[n]["titulo"])}</a> '
        f'<small>({"dif "+str(musicas[n]["dificuldade"]) if musicas[n]["dificuldade"] else "a verificar"})</small></li>'
        for n in s["musicas_foco"] if n in musicas)
    leit = "".join(
        f'<li><a href="#m{n:03d}">{n:03d} — {esc(musicas[n]["titulo"])}</a></li>'
        for n in s["leitura_1avista"] if n in musicas)
    return f'''<section class="semana" id="s{s['n']}">
      <div class="shead"><span class="snum">Semana {s['n']}</span><h3>{esc(s['tema'])}</h3></div>
      <div class="sgrid">
        <div><b>Tom</b><span>{esc(s['tom'])}</span></div>
        <div><b>Célula-alvo</b><span>{esc(s['celula_alvo'])}</span></div>
        <div><b>Requisito novo</b><span>{esc(s['requisito'])}</span></div>
      </div>
      <p class="licao">{esc(s['licao'])}</p>
      <div class="cols">
        <div><h5>Músicas em foco</h5><ul>{foco}</ul></div>
        <div><h5>Leitura à primeira vista</h5><ul>{leit}</ul></div>
      </div>
    </section>'''

rotina = "".join(
    f'<li><span class="rmin">{b["min"]}min</span> <b>{esc(b["bloco"])}</b> — {esc(b["conteudo"])}</li>'
    for b in jornada["rotina_diaria"])
tot = sum(b["min"] for b in jornada["rotina_diaria"])

cels_html = "".join(f'<li><code>{k}</code> {esc(v)}</li>' for k,v in cel.items())
arps_html = "".join(f'<li><code>{k}</code> {esc(v)}</li>' for k,v in arp.items())
semanas_html = "".join(secao_semana(s) for s in jornada["semanas"])
musicas_html = "".join(card_musica(musicas[n]) for n in sorted(musicas))

HTML = f'''<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>O Caminho do Sambrass — Trompete</title>
<style>
:root{{--tinta:#1a1a1a;--papel:#fbfaf7;--linha:#d8d2c4;--destaque:#7a1f1f;--suave:#6b6456;--caixa:#f2efe6;--verde:#2e6b4f}}
*{{box-sizing:border-box}}html{{scroll-behavior:smooth}}
body{{margin:0;background:var(--papel);color:var(--tinta);font-family:Georgia,'Times New Roman',serif;font-size:17px;line-height:1.5;padding:0 16px}}
.wrap{{max-width:920px;margin:0 auto}}
header.capa{{text-align:center;padding:52px 0 32px;border-bottom:3px double var(--tinta)}}
header.capa .sub{{font-family:Helvetica,Arial,sans-serif;letter-spacing:3px;text-transform:uppercase;font-size:12px;color:var(--suave)}}
header.capa h1{{font-size:32px;margin:10px 0 4px}}
header.capa .faixa{{font-style:italic;color:var(--destaque)}}
nav.toc{{background:var(--caixa);border:1px solid var(--linha);border-radius:6px;padding:14px 20px;margin:24px 0}}
nav.toc a{{color:var(--tinta);text-decoration:none;margin-right:14px;display:inline-block;padding:6px 0;min-height:36px;line-height:24px}}
nav.toc a:hover{{color:var(--destaque)}}
h2.sec{{font-family:Helvetica,Arial,sans-serif;font-size:14px;letter-spacing:1px;text-transform:uppercase;color:var(--destaque);border-bottom:1px solid var(--linha);padding-bottom:6px;margin:40px 0 14px}}
ul.rotina{{list-style:none;padding:0}}ul.rotina li{{padding:9px 12px;border:1px solid var(--linha);border-radius:5px;margin-bottom:7px;background:#fff}}
.rmin{{display:inline-block;min-width:52px;font-family:Helvetica,Arial,sans-serif;font-weight:bold;color:var(--verde)}}
.semana{{margin:22px 0;padding:18px;border:1px solid var(--linha);border-radius:8px;background:#fff}}
.shead{{display:flex;align-items:baseline;gap:12px;flex-wrap:wrap}}
.snum{{font-family:Helvetica,Arial,sans-serif;font-weight:bold;color:#fff;background:var(--destaque);border-radius:4px;padding:3px 10px;font-size:13px}}
.shead h3{{margin:0;font-size:21px}}
.sgrid{{display:flex;gap:18px;flex-wrap:wrap;margin:12px 0;font-size:14px}}
.sgrid div{{background:var(--caixa);border-radius:5px;padding:7px 11px}}.sgrid b{{display:block;font-family:Helvetica,Arial,sans-serif;font-size:11px;letter-spacing:1px;text-transform:uppercase;color:var(--suave)}}
.licao{{font-size:15px}}
.cols{{display:flex;gap:24px;flex-wrap:wrap}}.cols>div{{flex:1;min-width:240px}}
.cols h5{{font-family:Helvetica,Arial,sans-serif;font-size:12px;letter-spacing:1px;text-transform:uppercase;color:var(--suave);margin:8px 0 4px}}
.cols ul{{margin:0;padding-left:18px}}.cols a{{color:var(--destaque);text-decoration:none}}
.vocab{{display:flex;gap:24px;flex-wrap:wrap}}.vocab>div{{flex:1;min-width:260px}}
.vocab ul{{list-style:none;padding:0}}.vocab li{{padding:5px 0;font-size:15px;border-bottom:1px dotted var(--linha)}}
.vocab code{{background:var(--caixa);padding:2px 7px;border-radius:4px;font-weight:bold;color:var(--destaque);margin-right:6px}}
.musica{{border:1px solid var(--linha);border-radius:8px;padding:14px;margin:14px 0;background:#fff;scroll-margin-top:14px}}
.mhead{{display:flex;align-items:center;gap:12px}}
.mnum{{font-family:Helvetica,Arial,sans-serif;font-weight:bold;font-size:18px;color:var(--destaque);min-width:40px}}
.mhead h4{{margin:0;font-size:18px}}.comp{{font-size:13px;color:var(--suave)}}
.dif{{margin-left:auto;font-family:Helvetica,Arial,sans-serif;font-size:12px;font-weight:bold;padding:3px 9px;border-radius:12px;color:#fff}}
.d3{{background:#2e6b4f}}.d4{{background:#5a7a1f}}.d5{{background:#8a5a1f}}.d6{{background:#a3431f}}.d7{{background:#7a1f1f}}.dna{{background:#999}}
.mmeta{{font-size:13px;color:var(--suave);margin:7px 0}}
.reqs .req{{display:inline-block;font-size:11px;background:var(--caixa);border:1px solid var(--linha);border-radius:10px;padding:2px 8px;margin:2px 3px 2px 0;font-family:Helvetica,Arial,sans-serif}}
.cels{{font-family:Helvetica,Arial,sans-serif;font-size:12px;color:var(--verde);margin:4px 0}}
.musica img{{width:100%;height:auto;border:1px solid var(--linha);border-radius:5px;margin-top:8px;background:#fff}}
.obs{{font-size:14px;color:var(--suave);font-style:italic}}
footer{{margin:56px 0 40px;padding-top:22px;border-top:3px double var(--tinta);font-size:13px;color:var(--suave);text-align:center}}
</style></head><body><div class="wrap">

<header class="capa">
  <div class="sub">Estudo pessoal · caderno de naipe Sambrass23</div>
  <h1>O Caminho do Sambrass</h1>
  <div class="faixa">Trompete · jornada de 6 semanas para dominar o repertório</div>
</header>

<nav class="toc">
  <a href="#rotina">Rotina diária</a>
  <a href="#vocab">Vocabulário</a>
  <a href="#jornada">As 6 semanas</a>
  <a href="#banco">Banco de músicas</a>
</nav>

<h2 class="sec" id="rotina">A rotina de 1h30, todos os dias ({tot} min)</h2>
<ul class="rotina">{rotina}</ul>

<h2 class="sec" id="vocab">O vocabulário do caderno</h2>
<p>O Sambrass é homogêneo: quase tudo é 2/4 em Fá, Sol ou Ré, feito de poucas células rítmicas e arpejos que reaparecem em todas as peças. Dominar este vocabulário <b>é</b> aprender a ler o caderno à primeira vista.</p>
<div class="vocab">
  <div><h5 style="font-family:Helvetica,Arial,sans-serif;color:var(--suave);font-size:12px;letter-spacing:1px;text-transform:uppercase">Células rítmicas</h5><ul>{cels_html}</ul></div>
  <div><h5 style="font-family:Helvetica,Arial,sans-serif;color:var(--suave);font-size:12px;letter-spacing:1px;text-transform:uppercase">Arpejos &amp; intervalos</h5><ul>{arps_html}</ul></div>
</div>

<h2 class="sec" id="jornada">A jornada — 6 semanas</h2>
{semanas_html}

<h2 class="sec" id="banco">Banco de músicas ({len(musicas)} catalogadas)</h2>
<p>Partituras do caderno (recortadas sem a letra, que é protegida). Dificuldade 1–10 por análise da partitura; as marcadas "a verificar" têm a estrutura pronta e aguardam leitura.</p>
{musicas_html}

<footer>
  O Caminho do Sambrass — Trompete · material de estudo pessoal<br>
  Partituras referenciadas ao caderno de naipe Sambrass23. Letras não reproduzidas (direito autoral).<br>
  Banco e site gerados a partir de <code>data/*.json</code> · pronto para expansão no Claude Code.
</footer>
</div></body></html>'''

(ROOT/"site").mkdir(exist_ok=True)
out = ROOT/"site"/"index.html"
out.write_text(HTML, encoding="utf-8")
print("site gerado:", out, f"({len(HTML)} bytes)")
