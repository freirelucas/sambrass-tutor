import json

# 15 verificadas por leitura visual direta + 15 candidatas conhecidas marcadas p/ verificar.
# verificada=True só onde abri a partitura nesta/anteriores sessões.
musicas = [
  # --- VERIFICADAS ---
  {"num":9,"titulo":"O Sol Nascerá","compositor":"Cartola / Elton Medeiros","tom":"Fá","compasso":"2/4","densidade":"baixa","forma":["A","B"],"celulas":["C1","C2","C5"],"arpejos":["A1"],"dificuldade":3,"requisitos":["frases-curtas","tercina-leve-secao-B"],"verificada":True,"obs":"Mais acessível do caderno. A em valores longos; B traz tercinas e cromatismo pontual."},
  {"num":35,"titulo":"Tristeza","compositor":"Haroldo Lobo / Niltinho","tom":"Sol","compasso":"2/4","densidade":"baixa-média","forma":["A","B","C"],"celulas":["C1","C6"],"arpejos":["A1","A2"],"dificuldade":3,"requisitos":["frases-repetitivas-respiráveis","D.S."],"verificada":True,"obs":"Frases curtas e repetitivas, muito respirável. Tem dal segno."},
  {"num":1,"titulo":"Até Amanhã","compositor":"Noel Rosa","tom":"Fá","compasso":"2/4","densidade":"média","forma":["A","B"],"celulas":["C1","C2"],"arpejos":["A1"],"dificuldade":4,"requisitos":["síncope","casas-1-2"],"verificada":True,"obs":"Síncope clássica do samba + casas 1ª/2ª."},
  {"num":4,"titulo":"Fita Amarela","compositor":"Noel Rosa","tom":"Sib","compasso":"2/4","densidade":"média","forma":["A","B"],"celulas":["C1","C7"],"arpejos":["A1","A2"],"dificuldade":4,"requisitos":["tonalidade-2-bemóis","intro-7c","casas"],"verificada":True,"obs":"Sib (2 bemóis). Intro de 7 compassos; seção B respirável."},
  {"num":5,"titulo":"Acontece","compositor":"Cartola","tom":"Ré","compasso":"4/4","densidade":"média","forma":["A","B","C"],"celulas":["C1","C5"],"arpejos":["A1"],"dificuldade":4,"requisitos":["tonalidade-2-sustenidos","tercina"],"verificada":True,"obs":"A longa em valores médios; depois entram tercinas."},
  {"num":6,"titulo":"As Rosas Não Falam","compositor":"Cartola","tom":"Fá","compasso":"2/4","densidade":"média","forma":["A","B","C","D"],"celulas":["C1","C5"],"arpejos":["A1","A4"],"dificuldade":4,"requisitos":["forma-longa-ABCD","tercina","cromatismo-passagem"],"verificada":True,"obs":"Forma longa; colcheias com tercinas e bemóis de passagem."},
  {"num":25,"titulo":"Alguém Me Avisou","compositor":"Dona Ivone Lara","tom":"Fá","compasso":"2/4","densidade":"média","forma":["A","B"],"celulas":["C1","C2"],"arpejos":["A1"],"dificuldade":4,"requisitos":["síncope-leve","colcheias-em-grupo"],"verificada":True,"obs":"Colcheias em grupo com síncope leve."},
  {"num":68,"titulo":"Pra Que Chorar","compositor":"Baden Powell / Vinicius de Moraes","tom":"Sol","compasso":"2/4","densidade":"média","forma":["A","B","C"],"celulas":["C1","C2"],"arpejos":["A1","A2"],"dificuldade":5,"requisitos":["tonalidade-1-sustenido","fraseado-lírico","casas"],"verificada":True,"obs":"Lírica; colcheias em grupo, forma com casas."},
  {"num":34,"titulo":"Se Você Jurar","compositor":"Francisco Alves / Ismael Silva / Nilton Bastos","tom":"Sol","compasso":"2/4","densidade":"média","forma":["A","B","B'"],"celulas":["C1","C2"],"arpejos":["A1","A4"],"dificuldade":5,"requisitos":["cromatismo-sustenidos","forma-longa","casas"],"verificada":True,"obs":"Cromatismo de passagem (sustenidos); forma longa com casas."},
  {"num":44,"titulo":"Não Deixe o Samba Morrer","compositor":"Aloísio / Edson Conceição","tom":"Fá","compasso":"2/4","densidade":"média-alta","forma":["A","B","C"],"celulas":["C1","C2","C6"],"arpejos":["A1"],"dificuldade":5,"requisitos":["síncope","contratempo","forma-longa"],"verificada":True,"obs":"Síncope + contratempo; forma longa."},
  {"num":8,"titulo":"O Mundo é um Moinho","compositor":"Cartola","tom":"Ré","compasso":"4/4","densidade":"média-alta","forma":["A","B","C","D"],"celulas":["C1","C5"],"arpejos":["A1","A4"],"dificuldade":5,"requisitos":["tonalidade-2-sustenidos","tercina","forma-longa-ABCD","cromatismo"],"verificada":True,"obs":"Ré maior; tercinas e cromatismo; forma muito longa."},
  {"num":27,"titulo":"Sonho Meu","compositor":"Dona Ivone Lara / Délcio Carvalho","tom":"Ré","compasso":"2/4","densidade":"média-alta","forma":["A","B","C","D"],"celulas":["C1","C2"],"arpejos":["A1"],"dificuldade":5,"requisitos":["tonalidade-2-sustenidos","colcheias-densas","forma-longa-ABCD"],"verificada":True,"obs":"Colcheias densas; forma longa."},
  {"num":64,"titulo":"A Felicidade","compositor":"Tom Jobim / Vinicius de Moraes","tom":"Fá","compasso":"2/4","densidade":"média-alta","forma":["A","B"],"celulas":["C1","C2"],"arpejos":["A1","A4"],"dificuldade":5,"requisitos":["colcheias-densas","cromatismo-leve","fôlego-forma-larga"],"verificada":True,"obs":"Lírica e longa (40+ compassos); colcheias densas."},
  {"num":28,"titulo":"Casa de Bamba","compositor":"Martinho da Vila","tom":"Fá","compasso":"2/4","densidade":"alta","forma":["A","B","C"],"celulas":["C1","C2","C4"],"arpejos":["A1"],"dificuldade":6,"requisitos":["semicolcheias","forma-longa","articulação-rápida"],"verificada":True,"obs":"Semicolcheias densas; exige articulação e fôlego."},
  {"num":13,"titulo":"A Flor e o Espinho","compositor":"Nelson Cavaquinho / Guilherme de Brito / Alcides Caminha","tom":"Sol","compasso":"2/4","densidade":"alta","forma":["A","B","C"],"celulas":["C1","C2","C4"],"arpejos":["A1","A4"],"dificuldade":7,"requisitos":["semicolcheias","cromatismo-denso","forma-larga"],"verificada":True,"obs":"A mais difícil das vistas: semicolcheias + cromatismo."},
  # --- CANDIDATAS NÃO VERIFICADAS (estrutura pronta; difem/requisitos a confirmar na partitura) ---
  {"num":2,"titulo":"Com Que Roupa","compositor":"Noel Rosa","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"A verificar."},
  {"num":3,"titulo":"Feitiço da Vila","compositor":"Noel Rosa / Vadico","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"A verificar."},
  {"num":10,"titulo":"Preciso Me Encontrar","compositor":"Candeia","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"A verificar."},
  {"num":17,"titulo":"A Voz do Morro","compositor":"Zé Kéti","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"A verificar."},
  {"num":22,"titulo":"Trem das Onze","compositor":"Adoniran Barbosa","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"A verificar."},
  {"num":36,"titulo":"Vou Festejar","compositor":"Jorge Aragão / Dida / Neoci","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"A verificar."},
  {"num":54,"titulo":"Dança da Solidão","compositor":"Paulinho da Viola","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"A verificar."},
  {"num":61,"titulo":"Quem Te Viu, Quem Te Vê","compositor":"Chico Buarque","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"A verificar."},
  {"num":67,"titulo":"O Morro Não Tem Vez","compositor":"Tom Jobim / Vinicius de Moraes","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"A verificar."},
  {"num":55,"titulo":"Foi um Rio Que Passou em Minha Vida","compositor":"Paulinho da Viola","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"A verificar."},
  {"num":85,"titulo":"Mas Que Nada","compositor":"Jorge Ben Jor","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"A verificar."},
  {"num":87,"titulo":"Maracangalha","compositor":"Dorival Caymmi","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"A verificar."},
  {"num":84,"titulo":"Flor de Lis","compositor":"Djavan","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"A verificar."},
  {"num":36,"titulo":"Vou Festejar","compositor":"Jorge Aragão","tom":"?","compasso":"2/4","densidade":"?","forma":[],"celulas":[],"arpejos":[],"dificuldade":None,"requisitos":[],"verificada":False,"obs":"duplicata-remover"},
]

# remove duplicata de 36
seen=set(); uniq=[]
for m in musicas:
    if m["num"] in seen: continue
    seen.add(m["num"]); uniq.append(m)
musicas = uniq

# adiciona caminho da imagem e ordena por número
for m in musicas:
    m["score_img"] = f"scores/sb-{m['num']:03d}.jpg"
musicas.sort(key=lambda x: x["num"])

# carrega o header já escrito e completa
with open('sambrass_course/data/musicas.json') as f:
    header = f.read()
body = ",\n".join("    "+json.dumps(m, ensure_ascii=False) for m in musicas)
full = header + "\n" + body + "\n  ]\n}\n"
with open('sambrass_course/data/musicas.json','w') as f:
    f.write(full)

# valida
data = json.load(open('sambrass_course/data/musicas.json'))
v = [m for m in data["musicas"] if m["verificada"]]
print("total no banco:", len(data["musicas"]))
print("verificadas:", len(v))
print("não-verificadas:", len(data["musicas"])-len(v))
