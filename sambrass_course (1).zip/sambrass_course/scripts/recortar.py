# Recorta as 110 partituras do PDF, mantendo só a região da pauta
# (corta a faixa superior com as letras, material protegido).
import os
from pdf2image import convert_from_path

DPI = 150
TOP_CROP = 0.255
pages = convert_from_path('sb.pdf', dpi=DPI, first_page=4, last_page=113)
os.makedirs('sambrass_course/site/scores', exist_ok=True)
for i, img in enumerate(pages):
    num = i + 1
    w, h = img.size
    img.crop((0, int(h*TOP_CROP), w, h)).save(f'sambrass_course/site/scores/sb-{num:03d}.jpg')
print('recortadas', len(pages))
