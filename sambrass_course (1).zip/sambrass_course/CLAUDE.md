# Contexto para o Claude Code

Projeto: site estático "O Caminho do Sambrass — Trompete" (GitHub Pages) + banco de dados.
Dono: Lucas (toca trompete nível intermediário). Objetivo: aprender 30 músicas do
caderno Sambrass23 em 6 semanas, 1h30/dia, e ler o caderno à primeira vista.

## Princípios de design (manter)
- Single-file HTML, sem framework, sem TypeScript, sem build obrigatório para visualizar.
- Fontes de sistema, 17px base, padding lateral 16px, tap targets ≥36px, Samsung antigo.
- Prosa terça e direta; sem anglicismos; mínimo de markdown.

## Pipeline de dados
`data/*.json` é a fonte da verdade. `scripts/build_site.py` regenera `site/index.html`.
Nunca editar `site/index.html` à mão — editar os JSON e rodar o build.

## Análise musical (validada)
O caderno é homogêneo: 2/4, tons Fá/Sol/Ré, colcheias em grupo + síncope como base.
Eixos de dificuldade (ordem): tonalidade → densidade rítmica → cromatismo → extensão da forma.
Síncope e semicolcheia são o que define o samba (e o ápice do curso).

## Tarefas abertas
- [ ] Verificar as 15 músicas `verificada:false` (preencher tom/dif/células lendo scores/).
- [ ] Escalar 30 → 110 no mesmo schema.
- [ ] Criar snippets VexFlow por célula (C1–C7) — isolam dificuldades para o bloco "célula do dia".
- [ ] (opcional) áudio de referência / metrônomo embutido no site.

## NÃO fazer
- Não reproduzir letras das canções (direito autoral).
- Não tentar OMR neste ambiente (falhou por memória; leitura visual é o método).
